from django.shortcuts import render,HttpResponse,redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *
from apps.processor.models import *
from apps.accounts.models import *
import string
import random
from django.core.mail import send_mail
from datetime import date
from django.db.models import Q
import csv
import pandas as pd
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse
from django.contrib.auth.hashers import make_password
from apps.processor.models import * 
from apps.processor2.models import *
from apps.growerpayments.models import *
import re
from apps.processor.views import generate_shipment_id



# Create your views here.


characters = list(string.ascii_letters + string.digits + "@#$%")
def generate_random_password():
    length = 8
    
    random.shuffle(characters)
    password =[]
    
    for i in range(length):
        password.append(random.choice(characters))
    return "".join(password)    

characters2 = list(string.ascii_letters + string.digits)


@login_required()   #create processor3
def add_processor3(request):
    context = {}
    if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
        
        if request.method == "POST":
            fein = request.POST.get('fein')
            entity_name = request.POST.get('entity_name')
            billing_address = request.POST.get('billing_address')
            shipping_address = request.POST.get('shipping_address')
            main_number = request.POST.get('main_number')
            main_fax = request.POST.get('main_fax')
            website = request.POST.get('website')
            contact_name = request.POST.get('contact_name')
            contact_email = request.POST.get('contact_email')
            contact_phone = request.POST.get('contact_phone')
            contact_fax = request.POST.get('contact_fax')
            
            counter = request.POST.get('counter')
            p_password_raw = generate_random_password()
            processor3 = Processor3(fein=fein,entity_name=entity_name,billing_address=billing_address,shipping_address=shipping_address,main_number=main_number,main_fax=main_fax,website=website)
            processor3.save()
            
            if User.objects.filter(email = contact_email).exists():
                messages.error(request,'This email is already exists')
            else:
                processor3_user = ProcessorUser3(processor3_id = processor3.id ,contact_name=contact_name,contact_email=contact_email,contact_phone=contact_phone,contact_fax=contact_fax,p_password_raw =p_password_raw )
                processor3_user.save()
                user = User(email = contact_email ,username= contact_email ,first_name=contact_name)
                user.set_password(p_password_raw)
                user.password_raw = p_password_raw
                user.is_processor3=True
                user.is_active=True
                user.save()
                user.role.add(Role.objects.get(role ='Processor3'))
                
                if int(counter) > 0 :
                    for i in range(1,int(counter)+1):
                        contact_name = request.POST.get('contact_name{}'.format(i))
                        contact_email= request.POST.get('contact_email{}'.format(i))
                        contact_phone = request.POST.get('contact_phone{}'.format(i))
                        contact_fax = request.POST.get('contact_fax{}'.format(i))
                        if User.objects.filter(email = contact_email).exists():
                            messages.error(request,'This email is already exists')
                        else:
                            password = generate_random_password()
                            processor_user3 = ProcessorUser3(processor3_id = processor3.id ,contact_name =contact_name ,contact_email=contact_email,contact_phone=contact_phone,contact_fax=contact_fax,p_password_raw =password)  
                            processor_user3.save()
                            user = User(email = contact_email ,username= contact_email ,first_name = contact_name)
                            user.set_password(p_password_raw)
                            user.password_raw = (p_password_raw)
                            user.is_processor3=True
                            user.is_active=True
                            user.save()
                            user.role.add(Role.objects.get(role = 'Processor3'))
            messages.success(request,'New Tier 3 Processor Added Successfully')                   
            return redirect('list_processor3')                
        return render(request, 'processor3/add_processor3.html' , context)       
                
                        
@login_required()  # show processor3 list
def processor3_list(request):
    context={}
    if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
        processor3 = ProcessorUser3.objects.all()
        context['processor'] = processor3
        return render(request,'processor3/list_processor3.html',context)
    else:
        return redirect('login')   
    
    # processor 3     
    if request.user.is_processor3:
        pass
        
    
@login_required()  # processor3 value edit
def processor3_update(request,pk):
    context={}
    if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
        obj_id  = ProcessorUser3.objects.get(id = pk)
        context['processor3'] = obj_id
        processor3 = Processor3.objects.get(id = obj_id.processor3_id )
        context['processor_3']  = processor3
        processor_email = obj_id.contact_email
        user = User.objects.get(email = processor_email)
        if request.method == 'POST':
            email_update = request.POST.get('contact_email1')
            name_update = request.POST.get('contact_name1')
            phone_update = request.POST.get('contact_phone1')
            fax_update = request.POST.get('contact_fax1')
            
            # obj_id.contact_email = email_update
            obj_id.contact_name = name_update
            obj_id.contact_phone = phone_update
            obj_id.contact_fax = fax_update
            obj_id.save()
            
            if email_update != processor_email:
                user.email = email_update
                user.username = email_update
                user.first_name = name_update
                user.save()
                obj_id.contact_email = email_update
                obj_id.save()
            else:
                user.first_name = name_update
                user.save()    
            messages.success(request,'Tire3 Processor Updated Successfully')  
            return redirect('list_processor3')
        return render(request , 'processor3/update_processor3.html', context)
    else:
        return redirect('list_processor3')       
    
 
@login_required()   #processor3 change password
def processor3_change_password(request,pk):
    context={}
    if request.user.is_superuser or 'SubAdmin' in  request.user.get_role() or 'SuperUser' in request.user.get_role():
        obj_processor3 = ProcessorUser3.objects.get(id = pk)
        user = User.objects.get(email = obj_processor3.contact_email)
        context["processor3"] = user
        
        if request.method == 'POST':
            password1= request.POST.get('password1')
            password2= request.POST.get('password2')
            if len(password1) != 0 and len(password2) != 0 and password1 != None and password2 != None and password1 == password2:
                password = make_password(password1)
                user.passowrd = password
                user.password_raw = password1
                user.save()
                obj_processor3.p_password_raw = password1
                obj_processor3.save()
                messages.success(request,'Password Changed Successfully')
        return render(request,'processor3/processor3_change_password.html',context)        
    else:
        return redirect('dashboard')            
    
    
@login_required()  #processor3 delete
def processor3_delete(request,pk):
    # obj_processor3 = ProcessorUser3.objects.get(id = pk)    
    # user = User.objects.get(email = obj_processor3.contact_email)
    # obj_processor3.delete()
    # user.delete()
    # return HttpResponse(1)
    obj_p3_user = ProcessorUser3.objects.get(id = pk)
    check_p3 = Processor3.objects.get(id = obj_p3_user.processor3.id)
    user = User.objects.get(email = obj_p3_user.contact_email)
    obj_p3_user.delete()
    check_p3.delete()
    user.delete()
    return HttpResponse(1)
      
      
@login_required()   #processor3 add processor3 user
def add_processor3_user(request,pk):
    context={}
    if request.user.is_superuser or 'SubAdmin' or request.user.get_role() or 'SuperUser' in request.user.get_role():
        processor3_user =  ProcessorUser3.objects.get(id = pk)
        processor3_id = processor3_user.processor3.id
        processor3 = Processor3.objects.get(id = processor3_id) 
        context['processor'] = processor3
        processor_user = ProcessorUser3.objects.filter(processor3_id = processor3.id)
        context['processor_user'] = processor_user
        if request.method == 'POST':
            counter = request.POST.get('counter')
            for i in range(1,int(counter)+ 1):
                contact_email = request.POST.get('contact_email{}'.format(i))
                contact_name = request.POST.get('contact_name{}'.format(i))
                contact_phone = request.POST.get('contact_phone{}'.format(i))
                contact_fax = request.POST.get('contact_fax{}'.format(i))
                if User.objects.filter(email = contact_email).exists():
                    messages.error(request,'email already exists')
                else:
                    p_password_raw = generate_random_password()
                    p_user = ProcessorUser3(processor3_id = processor3_id,contact_email = contact_email,contact_name = contact_name ,contact_phone = contact_phone ,contact_fax = contact_fax,p_password_raw = p_password_raw)   
                    p_user.save()
                    user = User(email = contact_email,username = contact_email ,first_name = contact_name )
                    user.set_password(p_password_raw)
                    user.password_raw = p_password_raw
                    user.save()
                    user.role.add(Role.objects.get(role = 'Processor3'))
            return redirect('list_processor3')       
        return render(request , 'processor3/add_processor3_user.html' ,context) 
    else:
        return redirect('login')
    
    
# @login_required()  # show processor3 list
# def check_riju(request):    
#     # context={}
#     if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
#         # processor3 = ProcessorUser3.objects.all()
#         # context['processor'] = processor3
#         return render(request,'processor3/test.html')
#     else:
#         return redirect('login')   
    
@login_required()
def inbound_shipment_list(request):
    try:
        context = {}
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
            #inbound management list for admin
            context["table_data"] = list(ShipmentManagement.objects.filter(receiver_processor_type="T3").values())
            print(context)
            return render (request, 'processor3/inbound_management_table.html', context)
        elif request.user.is_processor2 :
            processor_email = request.user.email
            p = ProcessorUser2.objects.get(contact_email=processor_email)
            processor_id = Processor2.objects.get(id=p.processor2.id).id
            #inbound management list for processor
            context["table_data"] = list(ShipmentManagement.objects.filter(receiver_processor_type="T3", processor2_idd=processor_id).values())
            return render (request, 'processor3/inbound_management_table.html', context)
        else:
            return redirect('login')  
    except:
        return render (request, 'processor3/inbound_management_table.html') 

@login_required()
def inbound_shipment_view(request, pk):
    try:
        context = {}
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role() or request.user.is_processor2:
            #inbound management list for admin
            context["shipment"] = list(ShipmentManagement.objects.filter(id=pk).values())
            return render (request, 'processor3/inbound_management_view.html', context)
        else:
            return redirect('login')  
    except:
        return render (request, 'processor3/inbound_management_view.html', context) 
    
@login_required()
def inbound_shipment_edit(request, pk):
    try:
        context = {}
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role() or request.user.is_processor2:
            #inbound management list for admin
            context["shipment"] = ShipmentManagement.objects.get(id=pk)
            data = request.POST
            if request.method == "POST":
                status = data.get('status')
                approval_date = data.get('approval_date')
                received_weight = data.get('received_weight')
                ticket_number = data.get('ticket_number')
                storage_bin_recive = data.get('storage_bin_recive')
                reason_for_disapproval = data.get('reason_for_disapproval')
                moisture_percent = data.get('moist_percentage')
                ShipmentManagement.objects.filter(id=pk).update(status=status,moisture_percent=moisture_percent, recive_delivery_date=approval_date,
                                                                received_weight=received_weight,ticket_number=ticket_number,
                                                                storage_bin_recive=storage_bin_recive, reason_for_disapproval=reason_for_disapproval)
                return redirect('inbound_shipment_list')
            return render(request, 'processor3/inbound_management_edit.html', context)
        else:
            return redirect('login')  
    except:
        return render(request, 'processor3/inbound_management_edit.html', context)

@login_required()
def receive_shipment(request):
    context = {}

    if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
        context["processor"] = list(Processor2.objects.filter(processor_type__type_name="T2").values("id", "entity_name"))
        
        context.update({
            "select_processor_name": None,
            "select_processor_id": None,
            "milled_value": "None",
        })

        if request.method == "POST":
            data = request.POST
            bin_pull = data.get("bin_pull")
            milled_value = data.get("milled_value")
            context.update({
                "select_processor_name": Processor2.objects.filter(id=int(bin_pull)).first().entity_name,
                "select_processor_id": bin_pull,
                "processor2_id": data.get("processor2_id"),
                "exp_yield": data.get("exp_yield"),
                "exp_yield_unit_id": data.get("exp_yield_unit_id"),
                "moist_percentage": data.get("moist_percentage"),
                "purchase_number": data.get("purchase_number"),
                "weight_prod_unit_id": data.get("weight_prod_unit_id"),
                "weight_prod": data.get("weight_prod"),
                "storage_bin_id": data.get("storage_bin_id"),
                "equipment_id": data.get("equipment_id"),
                "equipment_type": data.get("equipment_type"),
                "lot_number": data.get("lot_number"),
                "volume_shipped": data.get("volume_shipped"),
                "files": data.get("files"),
                "status": data.get("status"),
                "receiver_sku_id": data.get("receiver_sku_id"),
                "received_weight": data.get("received_weight"),
                "ticket_number": data.get("ticket_number"),
                "approval_date": data.get("approval_date"),
                "milled_value":data.get('milled_value')
            })

            if bin_pull and not data.get("save"):
                list_get_bin_location = []
                get_bin_location = list(ProductionManagementProcessor2.objects.filter(processor_id=int(bin_pull)).values_list('milled_volume', flat=True))

                if get_bin_location:
                    for i in get_bin_location:
                        list_get_bin_location.append(float(i))

                total_shiped_volume = []
                shiped_volume = list(ShipmentManagement.objects.filter(bin_location=bin_pull).values_list('volume_shipped', flat=True))
                if shiped_volume:
                    for i in shiped_volume :
                        total_shiped_volume.append(float(i))

                sum_total_volume = sum(list_get_bin_location) if get_bin_location else 0
                sum_shiped_volume = sum(total_shiped_volume) if shiped_volume else 0
                
                context["milled_value"] =  float(sum_total_volume) - float(sum_shiped_volume)               
                
                processor3 = LinkProcessorToProcessor.objects.filter(processor_id=bin_pull, linked_processor__processor_type__type_name = "T3").values("linked_processor__id", "linked_processor__entity_name")
                processor4 = LinkProcessorToProcessor.objects.filter(processor_id=bin_pull, linked_processor__processor_type__type_name = "T4").values("linked_processor__id", "linked_processor__entity_name")
                context["processor3"] = processor3
                context["processor4"] = processor4
            
                return render(request, 'processor3/receive_delivery.html', context)
            else:
                print("okay piu")
                if context["weight_prod_unit_id"] == "LBS" :
                    cal_weight = round(float(context["weight_prod"]),2)
                if context["weight_prod_unit_id"] == "BU" :
                    cal_weight = round(float(context["weight_prod"]) * 45,2)
                if context["exp_yield_unit_id"] == "LBS" :
                    cal_exp_yield = round(float(context["exp_yield"]),2)
                if context["exp_yield_unit_id"] == "BU" :
                    cal_exp_yield = round(float(context["exp_yield"]) * 45,2)


                ### processor link part

                select_proc_id, processor_type = context["processor2_id"].split()
                
                if processor_type == 'T3':
                    select_destination_ = Processor2.objects.get(id=select_proc_id).entity_name
                    receiver_processor_type = "T3"
                    # print("select_destination_-----",select_destination_)
                elif processor_type == 'T4':
                    select_destination_ = Processor2.objects.get(id=select_proc_id).entity_name
                    receiver_processor_type = "T4"
               
                milled_volume = context["milled_value"]
                volume_left = float(context["milled_value"]) - float(context["volume_shipped"])
                shipment_id = generate_shipment_id()
                
                processor_e_name = Processor2.objects.filter(id=int(bin_pull)).first().entity_name
                save_shipment_management = ShipmentManagement(shipment_id=shipment_id,processor_idd=bin_pull,processor_e_name=processor_e_name, sender_processor_type="T1", bin_location=bin_pull,
                        equipment_type=context["equipment_type"],equipment_id=context["equipment_id"],storage_bin_send=context["storage_bin_id"],moisture_percent = context["moist_percentage"],weight_of_product_raw = context["weight_prod"],
                        weight_of_product=cal_weight,weight_of_product_unit=context["weight_prod_unit_id"], excepted_yield_raw =context["exp_yield"],excepted_yield=cal_exp_yield,excepted_yield_unit=context["exp_yield_unit_id"],recive_delivery_date=context["approval_date"],
                        purchase_order_number=context["purchase_number"],lot_number=context["lot_number"],volume_shipped=context["volume_shipped"],milled_volume=milled_volume,volume_left=volume_left,editable_obj=True,status=context["status"],
                        storage_bin_recive=context["receiver_sku_id"],ticket_number=context["ticket_number"],received_weight=context["received_weight"],processor2_idd=select_proc_id,processor2_name=select_destination_, receiver_processor_type=receiver_processor_type)
                save_shipment_management.save()
                print(save_shipment_management)
                print(context["files"])
                
                return redirect('inbound_shipment_list')
        return render(request, 'processor3/receive_delivery.html', context)
    else:
        return redirect('login')

@login_required
def add_outbound_shipment_processor3(request):
    context = {}

    if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
        # processor= Processor2.objects.filter(processor_type__type_name="T2").values("entity_name","id").order_by('entity_name')
        # processor3= Processor2.objects.filter(processor_type__type_name="T3").values("entity_name","id").order_by('entity_name')
        # processor4= Processor2.objects.filter(processor_type__type_name="T4").values("entity_name","id").order_by('entity_name')
        # context["processor3"] = processor3
        # context["processor4"] = processor4
        context["processor"] = list(Processor2.objects.filter(processor_type__type_name="T3").values("id", "entity_name"))
        
        context.update({
            "select_processor_name": None,
            "select_processor_id": None,
            "milled_value": "None",
        })

        if request.method == "POST":
            data = request.POST
            bin_pull = data.get("bin_pull")
            milled_value = data.get("milled_value")
            context.update({
                "select_processor_name": Processor2.objects.filter(id=int(bin_pull)).first().entity_name,
                "select_processor_id": bin_pull,
                "processor2_id": data.get("processor2_id"),
                "exp_yield": data.get("exp_yield"),
                "exp_yield_unit_id": data.get("exp_yield_unit_id"),
                "moist_percentage": data.get("moist_percentage"),
                "purchase_number": data.get("purchase_number"),
                "weight_prod_unit_id": data.get("weight_prod_unit_id"),
                "weight_prod": data.get("weight_prod"),
                "storage_bin_id": data.get("storage_bin_id"),
                "equipment_id": data.get("equipment_id"),
                "equipment_type": data.get("equipment_type"),
                "lot_number": data.get("lot_number"),
                "volume_shipped": data.get("volume_shipped"),
                "files": data.get("files"),
                "milled_value":data.get('milled_value')
            })

            if bin_pull and not data.get("save"):
                list_get_bin_location = []
                get_bin_location = list(ProductionManagementProcessor2.objects.filter(processor_id=int(bin_pull)).values_list('milled_volume', flat=True))

                if get_bin_location:
                    for i in get_bin_location:
                        list_get_bin_location.append(float(i))

                total_shiped_volume = []
                shiped_volume = ShipmentManagement.objects.filter(bin_location=bin_pull).values('volume_shipped')
                if shiped_volume:
                    for i in shiped_volume :
                        total_shiped_volume.append(float(i['volume_shipped']))

                sum_total_volume = sum(list_get_bin_location) if get_bin_location else 0
                sum_shiped_volume = sum(total_shiped_volume) if shiped_volume else 0
                context["milled_value"] =  float(sum_total_volume) - float(sum_shiped_volume)
                
                processor3 = LinkProcessorToProcessor.objects.filter(processor_id=bin_pull, linked_processor__processor_type__type_name = "T3").values("linked_processor__id", "linked_processor__entity_name")
                processor4 = LinkProcessorToProcessor.objects.filter(processor_id=bin_pull, linked_processor__processor_type__type_name = "T4").values("linked_processor__id", "linked_processor__entity_name")
                context["processor3"] = processor3
                context["processor4"] = processor4
               
                return render(request, 'processor3/add_outbound_shipment_processor3.html', context)
            else:
                if context["weight_prod_unit_id"] == "LBS" :
                    cal_weight = round(float(context["weight_prod"]),2)
                if context["weight_prod_unit_id"] == "BU" :
                    cal_weight = round(float(context["weight_prod"]) * 45,2)
                if context["exp_yield_unit_id"] == "LBS" :
                    cal_exp_yield = round(float(context["exp_yield"]),2)
                if context["exp_yield_unit_id"] == "BU" :
                    cal_exp_yield = round(float(context["exp_yield"]) * 45,2)


                ### processor link part

                select_proc_id, processor_type = context["processor2_id"].split()
                
                if processor_type == 'T4':
                    select_destination_ = Processor2.objects.get(id=select_proc_id).entity_name
                    receiver_processor_type = "T4"
                
                milled_volume = context["milled_value"]
                volume_left = float(context["milled_value"]) - float(context["volume_shipped"])
                shipment_id = generate_shipment_id()
                
                processor_e_name = Processor2.objects.filter(id=int(bin_pull)).first().entity_name
                save_shipment_management = ShipmentManagement(shipment_id=shipment_id,processor_idd=bin_pull,processor_e_name=processor_e_name, sender_processor_type="T3", bin_location=bin_pull,
                        equipment_type=context["equipment_type"],equipment_id=context["equipment_id"],storage_bin_send=context["storage_bin_id"],moisture_percent = context["moist_percentage"],weight_of_product_raw = context["weight_prod"],
                        weight_of_product=cal_weight,weight_of_product_unit=context["weight_prod_unit_id"], excepted_yield_raw =context["exp_yield"],excepted_yield=cal_exp_yield,excepted_yield_unit=context["exp_yield_unit_id"],
                        purchase_order_number=context["purchase_number"],lot_number=context["lot_number"],volume_shipped=context["volume_shipped"],milled_volume=milled_volume,volume_left=volume_left,editable_obj=True,
                        processor2_idd=select_proc_id,processor2_name=select_destination_, receiver_processor_type=receiver_processor_type)
                save_shipment_management.save()
                return redirect('outbound_shipment_list_processor3')

        return render(request, 'processor3/add_outbound_shipment_processor3.html', context)

@login_required()
def outbound_shipment_list_processor3(request):  
    try:
        context = {}
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
            #inbound management list for admin
            context["table_data"] = list(ShipmentManagement.objects.filter(sender_processor_type="T3").values())
            print(context)
            return render (request, 'processor3/outbound_shipment_list.html', context)
        elif request.user.is_processor2 :
            processor_email = request.user.email
            p = ProcessorUser2.objects.get(contact_email=processor_email)
            processor_id = Processor2.objects.get(id=p.processor2.id).id
            #inbound management list for processor
            context["table_data"] = list(ShipmentManagement.objects.filter(receiver_processor_type="T3", processor2_idd=processor_id).values())
            return render (request, 'processor3/outbound_shipment_list.html', context)
        else:
            return redirect('login')  
    except:
        return render (request, 'processor3/outbound_shipment_list.html') 


@login_required()
def processor3_processor_management(request):
    if request.user.is_authenticated:
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
            context ={}
            processor3 = Processor2.objects.filter(processor_type__type_name="T3")  #24/04/2024
            context['Processor1'] = processor3
            link_processor_to_processor_all = LinkProcessorToProcessor.objects.filter(processor__processor_type__type_name="T3")
            context['link_processor_to_processor_all'] = link_processor_to_processor_all
            
            if request.method == 'POST':
                pro1_id = request.POST.get('pro1_id')
                if pro1_id != '0':
                    context['link_processor_to_processor_all'] = link_processor_to_processor_all.filter(processor1_id=int(pro1_id))
                    #then need to add T1/T2/T3
                    context['selectedpro1'] = int(pro1_id)             
            print(context)             
            return render(request, 'processor3/processor3_processor_management.html',context)
    else:
        return redirect('login')


@login_required
def link_processor_three(request):
    context = {}
    try:
        if request.user.is_superuser or 'SubAdmin' in request.user.get_role() or 'SuperUser' in request.user.get_role():
            processor2 = Processor2.objects.filter(processor_type__type_name="T3")           
            context["processor2"] = processor2
           
            context["processor4"] = []

            if request.method == "POST" :
                selected_processor = request.POST.get("processor_id")
                button_click = request.POST.get("save")
                if selected_processor and  not button_click:
                    context["selectedprocessor"] = int(selected_processor)
                    link_processor2 = list(LinkProcessorToProcessor.objects.filter(processor_id=selected_processor).values_list("linked_processor", flat = True))
                    processor_two = Processor2.objects.exclude(id__in=link_processor2)
                    
                    processor4 = processor_two.filter(processor_type__type_name="T4")
                   
                    context["processor4"] = processor4
                    return render(request, 'processor3/link_processor3.html', context)
                else:
                    select_processor2 = request.POST.getlist("select_processor2")
                    print(selected_processor, select_processor2)
                    for i in select_processor2:
                        pro_id , pro_type = i.split(" ")
                        link_pro = LinkProcessorToProcessor(processor_id = selected_processor, linked_processor_id = pro_id)
                        link_pro.save()
                    return redirect('processor3_processor_management')
                    # return render(request, 'processor2/link_processor.html', context)

            return render(request, 'processor3/link_processor3.html', context)
        else:
            return render(request, 'processor3/link_processor3.html', context) 
    except Exception as e:
        print(e)
        return render(request, 'processor3/link_processor3.html', context)


    