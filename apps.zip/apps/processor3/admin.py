from django.contrib import admin
from apps.processor3.models import *


# Register your models here.
admin.site.register(Processor3)
admin.site.register(ProcessorUser3)