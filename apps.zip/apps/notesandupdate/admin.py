from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.ReleaseNote)
admin.site.register(models.UpcomingDate)