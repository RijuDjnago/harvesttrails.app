from django.contrib import admin
from apps.chat.models import *
# Register your models here.
admin.site.register(ProcessorMsgboard)
admin.site.register(ProcessorMessage)