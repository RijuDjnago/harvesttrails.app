from django.apps import AppConfig


class DocusignConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.docusign'
