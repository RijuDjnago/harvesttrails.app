from django.contrib import admin
from .models import Gallery, Document

admin.site.register(Gallery)
admin.site.register(Document)