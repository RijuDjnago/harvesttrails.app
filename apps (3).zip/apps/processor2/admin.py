from django.contrib import admin
from apps.processor2.models import *

# Register your models here.
admin.site.register(Processor2)
admin.site.register(ProcessorUser2)
admin.site.register(Processor2Location)
admin.site.register(ProcessorType)
admin.site.register(LinkProcessor1ToProcessor)
admin.site.register(ProductionManagementProcessor2)
admin.site.register(LinkProcessorToProcessor)