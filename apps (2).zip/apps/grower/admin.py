from django.contrib import admin

from .models import Grower, Consultant

admin.site.register(Grower)
admin.site.register(Consultant)
#admin.site.register(SubSuperUser)
# admin.site.register(GrowerNotification)
